class Sample {
 public:
  static int add(int a, int b);
};
