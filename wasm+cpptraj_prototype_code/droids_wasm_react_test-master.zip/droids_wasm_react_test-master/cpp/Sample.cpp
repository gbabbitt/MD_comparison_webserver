#include "Sample.h"

int Sample::add(int a, int b) {
  return a + b;
}
